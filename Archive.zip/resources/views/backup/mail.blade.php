<div style="text-align: center">
	<h3>ระบบส่งเอกสารเพื่อขอกำหนดแต่งตั้งตำแหน่งทางวิชาการ</h3>
	<p>ระบบรีเซ็ตรหัสผ่าน</p>
	<a href="http://localhost:8000/password/reset/{{$hash}}">คลิก</a>
</div>